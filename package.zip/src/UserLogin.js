import React, { useState } from 'react';
import axios from 'axios'; // Import Axios for making HTTP requests
import './UserLogin.css'; 

function UserLogin() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState(null); // State to store login error

  const handleEmailChange = (event) => {
    setEmail(event.target.value);
  };

  const handlePasswordChange = (event) => {
    setPassword(event.target.value);
  };

  const handleSubmit = async (event) => {
    event.preventDefault();
    try {
      // Send a POST request to the server with the email and password
      const response = await axios.post('http://localhost:5000/api/auth/login', {
        email,
        password
      });

      // If the authentication is successful, redirect to the create component
      if (response.status === 200) {
        // Extract user's role from the response
        const { role } = response.data.user;
        
        // Check if the user is an admin
        if (role === 'admin') {
          // Redirect logic goes here for admin
          console.log("logged in as admin")
          window.location.href = '/create';
        } else {
          // Redirect logic goes here for non-admin users
          console.log("logged in as non-admin")
          window.location.href = '/user-panel';
        }
      }
    } catch (error) {
      console.error('Error during login:', error);
      // Set the error state to display error message to the user
      setError('Invalid email or password. Please try again.');
    }
  };

  return (
    <div className="login-container"> 
      <h2>Login</h2>
      <form onSubmit={handleSubmit}>
        <div>
          <label>Email:</label>
          <input
            type="email"
            value={email}
            onChange={handleEmailChange}
            required
          />
        </div>
        <div>
          <label>Password:</label>
          <input
            type="password"
            value={password}
            onChange={handlePasswordChange}
            required
          />
        </div>
        {error && <p className="error-message">{error}</p>} 
        <button type="submit">Login</button>
      </form>
    </div>
  );
}

export default UserLogin;
