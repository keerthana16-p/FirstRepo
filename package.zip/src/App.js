//  import './App.css';
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Create from './Create.js';
import Login from './UserLogin.js';
function App() {
  return (
    <>
  <BrowserRouter>
        <Routes>
          <Route path='/' element={<Login />} />
          <Route path='/create' element={<Create />} />
        </Routes>
    </BrowserRouter>
   </>
  );
}

export default App;
