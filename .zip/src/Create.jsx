import { useState } from 'react';
import Axios from 'axios'
import './Create.css';

const Create = () => {
    const [firstName, setFirstName] = useState(""); 
    const [lastName, setLastName] = useState(""); 
    const [email, setEmail] = useState("");
    const password = 'user';
    const [role, setRole] = useState("");
    const handleSubmit = (e) => {
        e.preventDefault()
        Axios.post('http://localhost:5000/api/user/create', { firstName, lastName, email, password, role })
        .then(response => { console.log("hi") })
        .catch(err => { console.log('error: ', err) })
    }
    return (
        <div className='createuser-container'>
            <form className='form-container' onSubmit={handleSubmit}>
                <h2>Create User</h2>
                <label htmlFor='firstName'>First Name:</label>
                <input type='text' placeholder='First_Name'
                    onChange={(e) => setFirstName(e.target.value)} />
                <label htmlFor='lastName'>Last Name:</label>
                <input type='text' placeholder='Last_Name'
                    onChange={(e) => setLastName(e.target.value)} />
                <label htmlFor='email'>Email:</label>
                <input type='text' placeholder='Email'
                    onChange={(e) => setEmail(e.target.value)} />
                <label htmlFor='password'> Password:</label>
                <input type="password" placeholder='Password' value={password} />
                <label htmlFor='role'>Role:</label>
                <input type='text' placeholder='Role'
                    onChange={(e) => setRole(e.target.value)} />
                <button type='submit'>Create User</button>
            </form>
        </div>
    )
};

export default Create;