import React, { useState } from 'react';
import axios from 'axios';
import './AddProject.css'; 

const AddProject = ({ onAdd }) => {
  const [projectId, setProjectId] = useState('');
  const [projectName, setProjectName] = useState('');
  const [projectDomain, setProjectDomain] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [priority, setPriority] = useState('');

  const handleAddProject = async () => {

     // Check if required fields are empty
     if (!projectId || !projectName || !projectDomain) {
      alert('Please fill out all required fields.');
      return;
    }
    const newProject = {
      id: projectId,
      name: projectName,
      domain: projectDomain,
      startDate: startDate,
      endDate: endDate,
      priority: priority
    };

    try {
      // Make POST request to backend API
      await axios.post('http://localhost:5000/api/projects/add', newProject);
      
      // Call the onAdd function passed from the parent component
      // to pass the new project data
      onAdd(newProject);

      // Reset form fields after adding project
      setProjectId('');
      setProjectName('');
      setProjectDomain('');
      setStartDate('');
      setEndDate('');
      setPriority('');

      // Notify user that project has been added
      alert('Project added successfully!');
    } catch (error) {
      // Handle error
      console.error('Error adding project:', error);
      // Notify user about the error
      alert('Error adding project. Please try again later.');
    }
  };

  return (
    <div className="add-project-container"> 
      <h2>Add Project</h2>
      <label>Project ID:</label>
      <input type="text" value={projectId} onChange={(e) => setProjectId(e.target.value)} />
      <label>Project Name:</label>
      <input type="text" value={projectName} onChange={(e) => setProjectName(e.target.value)} />
      <label>Project Domain:</label>
      <input type="text" value={projectDomain} onChange={(e) => setProjectDomain(e.target.value)} />
      <label>Start Date:</label>
      <input type="date" value={startDate} onChange={(e) => setStartDate(e.target.value)} />
      <label>End Date:</label>
      <input type="date" value={endDate} onChange={(e) => setEndDate(e.target.value)} />
      <label>Priority:</label>
      <select value={priority} onChange={(e) => setPriority(e.target.value)}>
        <option value="">Select Priority</option>
        <option value="High">High</option>
        <option value="Medium">Medium</option>
        <option value="Low">Low</option>
      </select>
      <button onClick={handleAddProject}>Add Project</button>
    </div>
  );
};

export default AddProject;
