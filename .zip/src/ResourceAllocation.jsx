import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './ResourceAllocation.css';

function ResourceAllocation() {
  const [projects, setProjects] = useState([]);
  const [users, setUsers] = useState([]);
  const [formData, setFormData] = useState({
    projectId: '',
    userIds: [],
    startDate: '',
    endDate: ''
  });
  const [projectAvailable, setProjectAvailable] = useState(true);

  useEffect(() => {
    fetchProjects();
    fetchUsers();
  }, []);

  const fetchProjects = () => {
    axios.get('http://localhost:5000/api/projects')
      .then(response => {
        setProjects(response.data);
      })
      .catch(error => {
        console.error('Error fetching projects:', error);
      });
  };

  const fetchUsers = () => {
    axios.get('http://localhost:5000/api/users')
      .then(response => {
        setUsers(response.data);
      })
      .catch(error => {
        console.error('Error fetching users:', error);
      });
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setFormData({
      ...formData,
      [name]: value
    });

    // Check project availability when projectId changes
    if (name === 'projectId') {
      checkProjectAvailability();
    }
  };

  const handleUserSelection = (e) => {
    const { options } = e.target;
    const selectedUserIds = [];
    for (let i = 0; i < options.length; i++) {
      if (options[i].selected) {
        selectedUserIds.push(options[i].value);
      }
    }
    setFormData({
      ...formData,
      userIds: selectedUserIds
    });
  };

  const checkProjectAvailability = () => {  
    axios.get(`http://localhost:5000/api/projects/check-availability/${formData.projectId}`)
      .then(response => {
        setProjectAvailable(response.data.available);
      })
      .catch(error => {
        console.error('Error checking project availability:', error);
      });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    console.log(formData);
    axios.post('http://localhost:5000/api/resources', formData)
      .then(response => {
        console.log('Resource allocation successful:', response.data);
        setFormData({
          projectId: '',
          userIds: [],
          startDate: '',
          endDate: ''
        });
      })
      .catch(error => {
        console.error('Error allocating resources:', error);
      });
  };

  return (
    <div className="resource-allocation-container">
      <h2>Resource Allocation</h2>
      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="projectId">Project ID:</label>
          <select id="projectId" name="projectId" value={formData.projectId} onChange={handleInputChange} required>
            <option value="">Select Project ID</option>
            {projects.map(project => (
              <option key={project._id} value={project.projectId}>{project.projectId}</option>
            ))}
          </select>
          {!projectAvailable && <p className="error-message">Project not available!</p>}
        </div>
        <div className="form-group">
          <label htmlFor="userIds">Select Users:</label>
          <select id="userIds" name="userIds" multiple value={formData.userIds} onChange={handleUserSelection} required>
            {users.map(user => (
              <option key={user._id} value={user.userID}>{user.userID}</option>
            ))}
          </select>
        </div>
        <div className="form-group">
          <label htmlFor="startDate">Start Date:</label>
          <input type="date" id="startDate" name="startDate" value={formData.startDate} onChange={handleInputChange} required />
        </div>
        <div className="form-group">
          <label htmlFor="endDate">End Date:</label>
          <input type="date" id="endDate" name="endDate" value={formData.endDate} onChange={handleInputChange} required />
        </div>
        <button type="submit">Allocate Resources</button>
      </form>
    </div>
  );
}

export default ResourceAllocation;
