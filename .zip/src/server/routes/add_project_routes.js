// routes/projectRoutes.js
const express = require('express');
const router = express.Router();
const projectController = require('../controller/add_project_controller');

router.post('/add', projectController.addProject);
router.get('/check-availability/:projectId', projectController.checkProjectAvailability);

module.exports = router;
