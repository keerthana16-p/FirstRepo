const Project = require('../models/project_model');

const projectController = {};

// Add a new project
projectController.addProject = async (req, res) => {
  try {
    const { projectId, projectName, projectDomain, startDate, endDate, priority } = req.body;
    const project = new Project({ projectId, projectName, projectDomain, startDate, endDate, priority });
    await project.save();
    res.status(201).json({ success: true, message: 'Project added successfully' });
  } catch (error) {
    console.error('Error adding project:', error);
    res.status(500).json({ success: false, message: 'Error adding project' });
  }
};

// Check project availability
projectController.checkProjectAvailability = async (req, res) => {
  try {
    const projectId = req.params.projectId;
    const project = await Project.findOne({ projectId });
    if (project) {
      res.status(200).json({ available: true });
    } else {
      res.status(404).json({ available: false });
    }
  } catch (error) {
    console.error('Error checking project availability:', error);
    res.status(500).json({ available: false });
  }
};

// Allocate resources to a project
projectController.allocateResources = async (req, res) => {
  try {
    const { projectId, userIds, startDate, endDate } = req.body;
    const project = await Project.findOne({ projectId });

    if (!project) {
      return res.status(404).json({ success: false, message: 'Project not found' });
    }

    project.userIds = userIds;
    project.startDate = startDate;
    project.endDate = endDate;
    
    await project.save();
    res.status(200).json({ success: true, message: 'Resources allocated successfully' });
  } catch (error) {
    console.error('Error allocating resources:', error);
    res.status(500).json({ success: false, message: 'Error allocating resources' });
  }
};

module.exports = projectController;
