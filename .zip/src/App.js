import { BrowserRouter, Routes, Route } from "react-router-dom";
import Create from './Create.jsx';
import Login from './UserLogin.jsx';
import AddProject from "./AddProject.jsx";
import ResourceAllocation from "./ResourceAllocation.jsx";
import AdminDashboard from "./AdminPage.jsx";
function App() {
  return (
    <>
  <BrowserRouter>
        <Routes>
          <Route path='/' element={<Login />} />
          <Route path='/create' element={<Create />} />
          <Route path='/addproject' element={<AddProject />} />
          <Route path='/resourceallocation' element={<ResourceAllocation />} />
          <Route path='/admindashboard' element={<AdminDashboard />} />
        </Routes>
    </BrowserRouter>
   </>
  );
}

export default App;
